package com.example.c2_professoryoshi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class TelaCandidatos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_candidatos)

        val novoTV = TextView(baseContext)
        novoTV.text = "meu texto"

    }
    fun utilizarAPI(){
        val retrofit = Retrofit.Builder()
            .baseUrl("https://5f97816842706e00169572fd.mockapi.io/recursoProva")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val requests = retrofit.create(CandidatosAPI::class.java)

        val CallNome = requests.getCandidatos()

        CallNome.enqueue(object: Callback<List<CandidatosConcorrendo>> {
            override fun onFailure(call: Call<List<CandidatosConcorrendo>>, t: Throwable) {
                Toast.makeText(applicationContext, "Falha $t", Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<List<CandidatosConcorrendo>>,
                response: Response<List<CandidatosConcorrendo>>
            ) {
                response.body()?.forEach{


                }
            }

        })

    }


}

