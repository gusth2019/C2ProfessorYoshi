package com.example.c2_professoryoshi

import android.telecom.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface CandidatosAPI {
    @GET("/nome")
    fun getCandidatos(): retrofit2.Call<List<CandidatosConcorrendo>>

    @GET("/nome/{id}")
    fun getCandidatos(@Path("id")id: Integer): retrofit2.Call<CandidatosConcorrendo>
}