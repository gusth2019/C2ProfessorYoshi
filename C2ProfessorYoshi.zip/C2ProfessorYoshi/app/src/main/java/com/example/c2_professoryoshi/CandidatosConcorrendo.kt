package com.example.c2_professoryoshi

data class CandidatosConcorrendo(
    val id: Integer,
    val nome: String,
    val candidatoEstado: String,
    val proposta: String,
    val jaFoiEleito: Boolean
)